// Jorien Wallast .. common Javascript routines

function updFooterVer()
{
  document.getElementById("jw-footer-tooltiptext").innerText = "v20230130.1215." + window.innerWidth + "x" + window.innerHeight;
}

updFooterVer();

window.addEventListener('resize', updFooterVer);
